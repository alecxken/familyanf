<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="menu-title">
                    <span>Admin Menu</span>
                </li>
                <li class="<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('dashboard')); ?>" class="<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>"><i
                            class="la la-dashboard text-success"></i>
                        <span>Main Dashboard</span></a>
                </li>

              <!-- Bank Module -->

  <li class="submenu">
    <a href="#"><i class="fa  fa-list-ul"></i> <span>Family Module</span> <span
            class="menu-arrow"></span></a>
    <ul style="display: none;">

        <li><a class="<?php echo e(request()->is('partners') ? 'active' : ''); ?>"
                href="<?php echo e(url('partners')); ?>">New Member</a></li>


    </ul>
</li>


                <li class="submenu">
                    <a href="#"><i class="fa fa-cogs"></i> <span>General Settings</span> <span
                            class="menu-arrow"></span></a>
                    <ul style="display: none;">

                        <li><a class="<?php echo e(request()->is('dropdown-settings') ? 'active' : ''); ?>"
                                href="<?php echo e(url('dropdown-settings')); ?>" class="nav-sub-link">Dropdown Settings</a></li>

                        @role('Admin')
                            <li><a class="<?php echo e(request()->is('create_user') ? 'active' : ''); ?>"
                                    href="<?php echo e(url('create_user')); ?>" class="nav-sub-link">User Management</a></li>

                            <li><a class="<?php echo e(request()->is('admin') ? 'active' : ''); ?>" href="<?php echo e(url('admin')); ?>"
                                    class="nav-sub-link">Role Management</a></li>
                        @endrole

                    </ul>
                </li>








            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\EPN\family_tree\resources\views/layouts/side.blade.php ENDPATH**/ ?>