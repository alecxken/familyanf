<div id="add_tribute" class="modal custom-modal fade" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">TRIBUTE CREATION</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Start the form -->
                <?php echo Form::open(['method' => 'post', 'url' => 'store-tvc-envs', 'files' => true ]); ?>


                <!-- Hidden token input -->

                <div class="row">
                    <!-- Date input -->
<!--                     <div class="form-group col-md-6">
                        <?php echo Form::label('C_Name', 'Date:', ['class' => 'col-form-label']); ?> -->
                        <input type="hidden" name='request_date' value="<?php echo e(\Carbon\Carbon::now('EAT')); ?>" class="form-control" readonly="" />
                  <!--   </div> -->
                  <div class="form-group col-md-6">
                    <?php echo Form::label('C_Name', 'Tribute To:', ['class' => 'col-form-label']); ?>

                    <input type="text" name='tribute_for' class="form-control" placeholder="a friend, Brother,Sister etc" required="" />
                </div>
                  <div class="form-group col-md-6">
                    <?php echo Form::label('C_Name', 'First Name:', ['class' => 'col-form-label']); ?>

                    <input type="text" name='first_name' class="form-control" required="" />
                </div>

                <div class="form-group col-md-6">
                    <?php echo Form::label('C_Name', 'Last  Name:', ['class' => 'col-form-label']); ?>

                    <input type="text" name='last_name' class="form-control" />
                </div>



                <div class="form-group col-md-6">
                    <?php echo Form::label('C_Name', 'Subject:', ['class' => 'col-form-label']); ?>

                    <input type="text" name='subject' class="form-control" required="" />
                </div>
                    <!-- Manager's Email input -->
                    <div class="form-group col-md-12">
                        <?php echo Form::label('C_Name', 'Message:', ['class' => 'col-form-label']); ?>

                        <textarea class="form-control" name="message" rows="2"></textarea>
                    </div>
                    <div class="form-group col-md-12">
                        <?php echo Form::label('C_Name', 'Photos :', ['class' => 'col-form-label']); ?>

                        <input type="files" name='photos[]' class="form-control"  />
                    </div>
 <!-- End the form -->
                <div class="modal-footer">
                    <?php echo e(Form::submit('Click To Submit Your Request', ['class' => 'btn btn-success pull-right'])); ?>

                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php /**PATH D:\EPN\family_tree\resources\views/tributemodal.blade.php ENDPATH**/ ?>