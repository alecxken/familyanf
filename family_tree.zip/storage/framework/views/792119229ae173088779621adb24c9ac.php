
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">

        <meta name="robots" content="noindex, nofollow">
        <title>UTV <?php echo $__env->yieldContent('title'); ?></title>

		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="myfiles/img/favicon.png">

		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('myfiles/css/bootstrap.min.css')); ?>">
		  <!-- Bootstrap 3.3.7 -->
 <!--  -->
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('myfiles/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('myfiles/Ionicons/css/ionicons.min.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('myfiles/line-awesome/css/line-awesome.min.css')); ?>">
  <!-- Theme style -->
		<!-- Fontawesome CSS -->
     <!--    <link rel="stylesheet" href="<?php echo e(asset('myfiles/css/font-awesome.min.css')); ?>">

		Lineawesome CSS
        <link rel="stylesheet" href="<?php echo e(asset('myfiles/css/line-awesome.min.css')); ?>"> -->

		<!-- Chart CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('myfiles/plugins/morris/morris.css')); ?>">



		<!-- Main CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('myfiles/css/style.css')); ?>">
<script src="<?php echo e(asset('jquery/dist/jquery.min.js')); ?>"></script>
 <link href="<?php echo e(asset('myfiles/css/toastr.min.css')); ?>" rel="stylesheet"/>
 

<!-- Morris.js charts -->
        <?php echo $__env->yieldContent('extracss'); ?>

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="mynew/myfiles/js/html5shiv.min.js"></script>
			<script src="mynew/myfiles/js/respond.min.js"></script>
		<![endif]-->
    </head>

    <body>
		<!-- Main Wrapper -->
        <div class="main-wrapper">

			<!-- Header -->
            <?php echo $__env->make('layouts.home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- /Header -->

			<!-- Sidebar -->

        <?php echo $__env->make('layouts.home.side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- /Sidebar -->

			<!-- Page Wrapper -->
            <div class="page-wrapper" style="<?php if($ttl=='HomePage') echo 'margin-left: auto;'; ?>">

				<!-- Page Content -->
                <div class="content container-fluid">

					<!-- Page Header -->
					<div class="page-header">
						<?php echo $__env->yieldContent('header'); ?>
					</div>
					<!-- /Page Header -->

						<?php echo $__env->yieldContent('content'); ?>

				</div>
				<!-- /Page Content -->

            </div>
			<!-- /Page Wrapper -->

        </div>
		<!-- /Main Wrapper -->

		<!-- jQuery -->
		  <?php echo $__env->yieldPushContent('scripts'); ?>
		   <script src="<?php echo e(asset('mynew/myfiles/js/jquery.min.js')); ?>"></script>
		<?php echo $__env->yieldContent('extrajs'); ?>





        <?php echo $__env->yieldPushContent('scripts'); ?>


        <script src="<?php echo e(asset('myfiles/js/jquery-3.5.1.min.js')); ?>"></script>
<!--        <script src="<?php echo e(asset('myfiles/js/jquery-3.2.1.min.js')); ?>"></script>  -->


     <!-- Bootstrap Core JS -->
     <script src="<?php echo e(asset('myfiles/js/popper.min.js')); ?>"></script>
     <script src="<?php echo e(asset('myfiles/js/bootstrap.min.js')); ?>"></script>

     <!-- Slimscroll JS -->
     <script src="<?php echo e(asset('myfiles/js/jquery.slimscroll.min.js')); ?>"></script>

     <!-- Chart JS -->
 <!--
     <script src="<?php echo e(asset('myfiles/js/chart.js')); ?>"></script> -->

     <!-- Custom JS -->
     <script src="<?php echo e(asset('myfiles/js/app.js')); ?>"></script>

     <?php echo $__env->yieldContent('extrajs'); ?>
     <script src="<?php echo e(asset('myfiles/js/toastr.js')); ?>"></script>
     <script type="text/javascript">
 toastr.options = {
   "closeButton": true,
 "debug": true,
 "newestOnTop": true,
 "progressBar": true,
// "positionClass": "toast-top-center",
// "preventDuplicates": true,
// "onclick": null,
"showDuration": "300",
"hideDuration": "1000",
"timeOut": "5000",
"extendedTimeOut": "1000",
"showEasing": "swing",
"hideEasing": "linear",
"showMethod": "fadeIn",
"hideMethod": "fadeOut"
}
<?php if(session("danger")): ?>
toastr.error("<?php echo e(session("danger")); ?>");
<?php elseif(session("status")): ?>
 toastr.success("<?php echo e(session("status")); ?>");
<?php elseif(session("success")): ?>
 toastr.success("<?php echo e(session("success")); ?>");
<?php elseif(session("info")): ?>
toastr.info("<?php echo e(session("info")); ?>");
<?php elseif(session("error")): ?>
toastr.error("<?php echo e(session("error")); ?>");
<?php elseif(session("warning")): ?>
toastr.warning("<?php echo e(session("warning")); ?>");

<?php endif; ?>
<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           toastr.warning("<?php echo e($error); ?>");
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>
</script>

 </body>
</html>
<?php /**PATH D:\EPN\family_tree\resources\views/layouts/home/template.blade.php ENDPATH**/ ?>